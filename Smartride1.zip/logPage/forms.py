from django import forms

# class NameForm(forms.Form):
#    	userId = models.CharField(max_length = 200 , label = 'userId')
# 	passWd = models.CharField(max_length = 200 , label = 'passWd')
# 	firstName = models.CharField(max_length = 200 , label = 'firstName')
# 	lastName = models.CharField(max_length = 200 , label = 'lastName')


