from django.apps import AppConfig


class LogpageConfig(AppConfig):
    name = 'logPage'
